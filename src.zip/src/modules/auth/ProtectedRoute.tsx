import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from './AuthContext'

export function ProtectedRoute() {
  const { user, token, loading } = useAuth()
  const loc = useLocation()

  // 1) Mientras carga, NO renderizar nada
  if (loading) return null

  // 2) Si no hay token → NO estás logueada
  if (!token) {
    return <Navigate to="/login" replace state={{ from: loc }} />
  }

  // 3) Si hay token pero aún no hay user, lo recupera del localStorage
  if (!user) {
    return <Navigate to="/login" replace state={{ from: loc }} />
  }

  // 4) Autorizado
  return <Outlet />
}
