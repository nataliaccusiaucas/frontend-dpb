export type Offer = {
    id: number
    title: string
    description: string
    budget: number
    createdAt: string
}
