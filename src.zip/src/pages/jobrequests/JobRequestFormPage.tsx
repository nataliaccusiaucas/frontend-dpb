import { JobRequestForm } from "../../modules/jobrequests/JobRequestForm"

export default function JobRequestFormPage() {
  return (
      <JobRequestForm />
  )
}
