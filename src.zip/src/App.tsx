import { Toaster } from './components/ui/Toaster'
import { AppRoutes } from './routes'
import { Navbar } from './components/Navbar'
import Footer from './components/Footer'
import { useLocation } from "react-router-dom"

export default function App() {
  const location = useLocation()

  const isAuthPage =
    location.pathname === "/login" ||
    location.pathname === "/register"

  const hideFooter = isAuthPage

  return (
    <div
      className={`min-h-screen flex flex-col ${
        isAuthPage ? "bg-white text-black" : "bg-black text-white"
      }`}
    >
      <Navbar />

      <main className="flex-grow">
        <AppRoutes />
      </main>

      {!hideFooter && <Footer />}

      <Toaster />
    </div>
  )
}
